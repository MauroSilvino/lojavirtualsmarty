<?php

Class Config{

//Informações básicas do site
const SITE_URL = "http://localhost";
const SITE_PASTA = "lojavirtual";
const SITE_NOME = "Loja CO. Musical - PHP 7 e Mysqli";
const SITE_EMAIL_ADM = "maurobio23@gmail.com";

//Informações do Banco de Dados
const BD_HOST = "localhost";
const BD_USER = "root";
const BD_SENHA = "jardim197";
const BD_BANCO = "lojavirtual";
const BD_PREFIX = "";

//Informação para PHP Mailler
const EMAIL_HOST = "smtp.gmail.com";
const EMAIL_USER = "maurobio23@gmail.com";
const EMAIL_NOME = "Contato Co. Musical";
const EMAIL_SENHA = "Eu2307Eu1993";
const EMAIL_PORTA = 587;
const EMAIL_SMTPAUTH = true;
const EMAIL_SMTPSECURE = "tls";
const EMAIL_COPIA = "maurobio23@gmail.com";

}
?>